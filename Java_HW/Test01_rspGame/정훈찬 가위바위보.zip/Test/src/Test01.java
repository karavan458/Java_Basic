/*
 * 작 성 자 : 정훈찬
 * 작성일자 : 2024-12-06
 * 사용버전 : openjdk21, eclipse IDE
 * 프로그램 목적 : 조건문을 사용한 가위바위보 프로그램 작성
*/

import java.util.Scanner;
import java.util.Random;


public class Test01 {
	public static void main(String[] agrs) {
		//난수 생성
		Random ran = new Random();
		int computerChoice = ran.nextInt(3) + 1;
		
		//내가 내고 싶은 것 저장
		System.out.print("바위, 가위, 보 중 하나를 입력하세요 : ");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		int myChoice = 0;
		
		System.out.println("===결과===");
		
		//내가 낸 것을 숫자로 치환
		if(str.equals("바위")) {
			myChoice = 1;
			System.out.println("당신 : 바위");
		}
		else if(str.equals("가위")) {
			myChoice = 2;
			System.out.println("당신 : 가위");
		}
		else if(str.equals("보")) {
			myChoice = 3;
			System.out.println("당신 : 보");
		}
		else System.out.println("이상한거 내지 마세요");
		
		//내가 낸 가위바위보와 컴퓨터의 가위바위보 비교
		int result = myChoice - computerChoice;
		
		//컴퓨터의 가위바위보 출력
		if(computerChoice == 1) System.out.println("컴퓨터 : 바위");
		else if(computerChoice == 2) System.out.println("컴퓨터 : 가위");
		else if(computerChoice == 3) System.out.println("컴퓨터 : 보");
		
		//가위바위보 결과 출력
		if(result == 0) System.out.println("결과 : 비겼습니다.");
		else if(result == -1 || result == 2) System.out.println("결과 : 당신이 이겼습니다.");
		else System.out.println("결과 : 당신이 졌습니다.");
	
		
		sc.close();
	}
}
